
/*var myApp = angular.module("MyApp",['ui.bootstrap']);
myApp.controller('customerCtrl', customerCtrl);
var customers=[];
customerCtrl.$inject = ['customerService', '$scope'];
function customerCtrl(customerService, $scope) {
  customerService.getCustomer().then(function (resp) {
    $scope.customers =  resp;
	  $scope.currentPage = 1;
  $scope.itemsPerPage = 12;

$scope.totalItems = $scope.customers.length;  
  },function(badResp){
    console.info(badResp);
  });
 
 
 $scope.SetView=function(event){
	 if(event.target.id==="grid")
	 {
	
           $('.amita').addClass('col-lg-3');
       } else {
           $('.amita').removeClass('col-lg-3');
           
       }
 }

$scope.addCustomer=function(){
	
$scope.name;
$scope.email;
$scope.address;
$scope.orders;


   $scope.customers.push({
       Name:$scope.name,
	   address: $scope.address,
       NoOfOrders:$scope.orders,
	   Email: $scope.email
      });

}

  $scope.limit = 8;
}

*/

var myApp = angular.module("MyApp",['ui.bootstrap']);

myApp.controller('customerListControl', ['$scope', '$http', function ($scope, $http) {
  $http.get('customers.json').success(function(data) {
    $scope.customers = data;
    $scope.totalItems = $scope.customers.length;
    console.log($scope.numPages);
  }).error(function() {
    console.log("error");
  });
  $scope.editedItem = {};
  $scope.currentPage = 1;
  $scope.itemsPerPage = 12;
  $scope.SetView=function(event){
	 if(event.target.id==="grid")
	 {
	
           $('.amita').addClass('col-lg-3');
       } else {
           $('.amita').removeClass('col-lg-3');
           
       }
 }

$scope.addCustomer=function(){
	
$scope.name;
$scope.email;
$scope.address;
$scope.orders;


   $scope.customers.push({
       Name:$scope.name,
	   address: $scope.address,
       NoOfOrders:$scope.orders,
	   Email: $scope.email
      });

}

  
  }]);
/* The controller for getting the car list */
listOfCars.controller('carList', function($scope, $http) {

    /* For getting the list of cars available */
    $scope.loadCar = function(){
    	$scope.number=0;
    	$scope.cars=[];
    	console.log($scope.number);
        $http({method: 'GET', url: 'pages/carlist'}).then(function(response) {
        	console.log($scope.number);
                $scope.cars = response.data;
        console.log($scope.cars);
                
        });
    }
});

/* Controller for getting the car details */
carDetails.controller('details', function($scope, $http) {
	
    console.log("sdsf");
    /* For loading the car details */
    $scope.getCarDetail = function(id){
    	$scope.number=0;
        console.log($scope.number);
    	$http({method: 'GET', url: 'pages/cardetails?id='+id}).then(function(response) {
    		$scope.number=0;
            console.log($scope.number);
                $scope.carDetail = response.data;
                console.log($scope.carDetail);
                    
          
        });
    }
});

/* Controller for the car create and edit form */
carForm.controller('formFilling', function($scope, $http) {

    /* For loading the car details */
    $scope.getCarDetail = function(id){
        if(angular.isUndefined(id)) {
            $scope.car = {};
        } else {
        	
            $http({method: 'GET', url: 'pages/cardetails?id='+id}).then(function(response) {
                if (response.status === 200) {
                    $scope.car = response.data;
                    console.log($scope.car)
                   
                }
            });
        }
    }

    /* For submitting the form data */
    $scope.submitForm = function() {
        $http({
            method : 'POST',
            url : '',
            data : $scope.customer,
            headers : {'Content-Type': 'application/json'}
        }).success(function(data) {
            $scope.cancel();
            $window.location.reload();
        });
    }
});

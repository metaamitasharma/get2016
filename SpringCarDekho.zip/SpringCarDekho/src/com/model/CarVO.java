package com.model;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class CarVO extends VehicleVO {

	
	String model,engineCC,AC,powerSteeer,accKit,name,id,creator;
	 CarVO carVoObj=null;
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	float fuelCap,mileage,price,roadTax;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngineCC() {
		return engineCC;
	}
	public void setEngineCC(String engineCC) {
		this.engineCC = engineCC;
	}
	
	public String getAC() {
		return AC;
	}
	public void setAC(String aC) {
		AC = aC;
	}
	public String getPowerSteeer() {
		return powerSteeer;
	}
	public void setPowerSteeer(String powerSteeer) {
		this.powerSteeer = powerSteeer;
	}
	public String getAccKit() {
		return accKit;
	}
	public void setAccKit(String accKit) {
		this.accKit = accKit;
	}
	public float getFuelCap() {
		return fuelCap;
	}
	public void setFuelCap(float fuelCap) {
		this.fuelCap = fuelCap;
	}
	public float getMileage() {
		return mileage;
	}
	public void setMileage(float mileage) {
		this.mileage = mileage;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getRoadTax() {
		return roadTax;
	}
	public void setRoadTax(float roadTax) {
		this.roadTax = roadTax;
	}
	
	/*public static CarVO getObject() {
		//Checking if facade object already exists or not
		if(carVoObj == null) {
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
			carVoObj = context.getBean("CarVO", CarVO.class);
			((ClassPathXmlApplicationContext)context).close();
		}
		return carVoObj;
	}
	
	*/
}

package com.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class CarDao {
	ConnectionFactory jdbc;
	Connection con=null;
	static CarDao carDaoObj=null;
	public CarDao()
	{
	
	 con= ConnectionFactory.getConnection();  
	 try
		{
		 con=jdbc.getConnection();
		 System.out.println("connection"+con);
		}
		catch(Exception e)
		{
			System.out.println("error in establishing connection");
		}
	}
	 public static java.sql.Date getCurrentJavaSqlDate() {
		    java.util.Date today = new java.util.Date();
		    return new java.sql.Date(today.getTime());
		  }
	
	public Boolean insertCar(CarVO car)
	{
	
		int f=0;
		
		
		String query="insert into Car(creator,createdTime,updateBy,updatedTime,model,engineCC,fuelCap,milage,price,tax,ac,powersteer,accKit,name) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		java.sql.Date date = getCurrentJavaSqlDate();
	     
		  
		ps.setString(1, car.getCreator());
		ps.setString(3, car.getCreator());
		
		ps.setDate(2, date);
		ps.setDate(4, date);
		ps.setString(5,car.getModel());
		ps.setString(6, car.getEngineCC());
		ps.setFloat(7,car.getFuelCap());
		ps.setFloat(8,car.getMileage());
		ps.setFloat(9,car.getPrice());
		ps.setFloat(10,car.getRoadTax());
		ps.setString(11, car.getAC());
		ps.setString(12,car.getPowerSteeer());
		ps.setString(13,car.getAccKit());
		ps.setString(14,car.getName());
		
 f=ps.executeUpdate();
 System.out.println("INSERT"+f);
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		try
		{
			
			
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		if(f>0)
	    
		return true;
		else
			return false;
	}
	public Boolean updateCar(String updateBased,CarVO car)
	{
	
		int f=0;
		
String query = "UPDATE car set creator=? , createdTime=? ,updateBy=? ,updatedTime=? ,model=? , engineCC=? , fuelcap=? , milage=? , price=? , tax=?"
		+ ", ac=? , powerSteer=? , accKit=? , name=? where model=?";
                

		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		java.sql.Date date = getCurrentJavaSqlDate();
	     
		   System.out.println(date);
		
		ps.setDate(2,date);
		System.out.println("date"+date);
		
	
		ps.setDate(4, date);
		System.out.println("date"+date);
	  ps.setString(5,car.getModel());
		System.out.println("model"+car.getModel());
		ps.setString(6, car.getEngineCC());
		System.out.println("engine"+car.getEngineCC());
		ps.setFloat(7,car.getFuelCap());
		System.out.println("fuel"+car.getFuelCap());
		ps.setFloat(8,car.getMileage());
		System.out.println("mileage"+car.getMileage());
		ps.setFloat(9,car.getPrice());
		System.out.println("price"+car.getPrice());
		ps.setFloat(10,car.getRoadTax());
		System.out.println("tax"+car.getRoadTax());
		ps.setString(11, car.getAC());
		System.out.println("ac"+car.getAC());
		ps.setString(12,car.getPowerSteeer());
		System.out.println("power"+car.getPowerSteeer());
		ps.setString(13,car.getAccKit());
		System.out.println("acckit"+car.getAccKit());
		ps.setString(14,car.getName());
		System.out.println("carname"+car.getName());
		ps.setString(15,updateBased);
		System.out.println("model"+updateBased);
        f=ps.executeUpdate();
        System.out.println(f);
		}
		catch(SQLException e)
		{
			System.out.println("riya"+e);
		}
		try
		{
			
			con.close();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		if(f>0)
	    
		return true;
		else
			return false;
	}
	public ResultSet searchCarByModel(String model)
	{
		
		ResultSet rs=null;
		 String query="select * from car where model=?";
		int i=0;
		try
		{PreparedStatement ps=null;
			
	 ps = con.prepareStatement(query);
			
	 ps.setString(1,model);
		 rs=ps.executeQuery();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		
		return rs;
		
	}
	public ResultSet viewCarList(String query)
	{
		ResultSet rs=null;
		int i=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
	
		 rs=ps.executeQuery();
		
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		return rs;
	}
	int searchCar(String car)
	{
		String query="select count(*) from car where name=?";
		int count=0;
		try
		{
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1,car);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			count=rs.getInt(1);
			
		}
		}
		catch(SQLException e)
		{
			System.out.println("Error"+e);
			
		}
		return count;
	}
	
	public static CarDao getObject() {
		//Checking if facade object already exists or not
		if(carDaoObj == null) {
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
			carDaoObj = context.getBean("CarDao", CarDao.class);
			((ClassPathXmlApplicationContext)context).close();
		}
		return carDaoObj;
	}
	
}

package com.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class CarFacade {
	
	
	static CarFacade carFacadeObject=null;
	
public static CarFacade getObject(){
	if(carFacadeObject == null) {
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		carFacadeObject = context.getBean("CarFacade", CarFacade.class);
		
	}
	return carFacadeObject;
}
	
	public ArrayList<CarVO> viewCars()
	{
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		CarDao carDAO = CarDao.getObject();
		ArrayList<CarVO> carList=new ArrayList<CarVO>();
		 try
	        {
			 String query="select model from car";
			 ResultSet rs=carDAO.viewCarList(query);
			 
	           while (rs.next()) {
	        	   CarVO car=context.getBean("CarVO", CarVO.class);
			System.out.println(rs.getString(1));
	        	   car.setModel(rs.getString(1));
				carList.add(car);
				
			}
	        }
	        catch(SQLException e)
	        {
	        	System.out.println(e.getMessage());
	        }
	  
		return carList;
	}
	
	public ArrayList<CarVO> searchCarByModel(String model)
	{
		CarDao carDAO = CarDao.getObject();
		ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		ArrayList<CarVO>carList=new ArrayList<CarVO>();
		 try
	        {
			
			 ResultSet rs=carDAO.searchCarByModel(model);
	        
	           while (rs.next()) {
				CarVO car=context.getBean("CarVO", CarVO.class);
				
				car.setId(rs.getString(1));
				car.setCreator(rs.getString(2));
				
				
				car.setModel(rs.getString(6));
				car.setEngineCC(rs.getString(7));
			    car.setFuelCap(rs.getFloat(8));
				car.setMileage(rs.getFloat(9));
				car.setPrice(rs.getFloat(10));
				car.setRoadTax(rs.getFloat(11));
				car.setAC(rs.getString(12));
				car.setPowerSteeer(rs.getString(13));
				car.setAccKit(rs.getString(14));
				carList.add(car);
			}
	        }
	        catch(SQLException e)
	        {
	        	System.out.println("Error in query");
	        }
	  
		return carList;
	}
	
	public Boolean addcar(CarVO car)
	{
		Boolean status=false;
		CarDao carDAO = CarDao.getObject();
		
	
		
			 status=carDAO.insertCar(car);
		
			// TODO Auto-generated catch block
			
		return status;
	}


}

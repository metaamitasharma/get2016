package com.controllers;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.CarFacade;
import com.model.CarVO;

@Controller
@RequestMapping("/pages/")
public class CarController {
	
	@RequestMapping(value="/carlist", method=RequestMethod.GET)
	 public @ResponseBody ArrayList<CarVO> showCarList(){
		System.out.println("Coming In carList");
		CarFacade carFacadeObject=CarFacade.getObject();
		ArrayList<CarVO> carList=carFacadeObject.viewCars();
		System.out.println(carList);
		System.out.println("Going From car List");
		return carList;
		
	}
	
	@RequestMapping(value="/cardetails", method=RequestMethod.GET)
	 public @ResponseBody ArrayList<CarVO> showCarList(@RequestParam("id") String model){
		System.out.println("Coming In fkjkfkdjk");
		CarFacade facadeObj=new CarFacade();
		ArrayList<CarVO> carList=facadeObj.searchCarByModel(model);
		System.out.println(carList);
		System.out.println("jgijifd Going From car List");
		System.out.println(carList);
		return carList;
		
		
	}
	
	
	
	

}

package com.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.CarFacade;
import com.model.CarVO;

@Controller
public class PageController {
	ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
	@RequestMapping("/")
	public String show(){
		
		return "index";
	}
	
	@RequestMapping("listCar")
	public String  getCarList(){
		
		return "displayCar";
	}
	
	@RequestMapping("cardetails")
	public String showCarDetailsPage(@RequestParam("id") String id, ModelMap model) {
	   
		System.out.println("is"+id);
		model.addAttribute("id", id);
		return "displayDetail";
	}
	
	@RequestMapping("caredit")
	public String showCarEditPage(@RequestParam("id") String id, ModelMap model) {
		model.addAttribute("id", id);
		return "carEdit";
	}
	@RequestMapping("createCar")
	public String showCarCreatePage() {
		
		return "createCar";
	}
	@RequestMapping("AddCar")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String carname=request.getParameter("carName");
		String carCreater=request.getParameter("carCreater");
		String model=request.getParameter("model");
		
		String mile=request.getParameter("milage");
		float mileage=Float.parseFloat(mile);
		String engineCC=request.getParameter("engine");
		String fuel=request.getParameter("fuel");
		float fuelCap=Float.parseFloat(fuel);
		String price=request.getParameter("price");
		float carPrice=Float.parseFloat(price);
		String tax=request.getParameter("tax");
		float roadTax=Float.parseFloat(tax);
		String ac=request.getParameter("ac");
		String powerSteer=request.getParameter("powerSteer");
		String accKit=request.getParameter("accKit");
		
	
	    CarVO car=context.getBean("CarVO", CarVO.class);
	    
	    car.setName(carname);
	    car.setCreator(carCreater);
		car.setModel(model);
		car.setMileage(mileage);
		car.setEngineCC(engineCC);
		car.setFuelCap(fuelCap);
		car.setPrice(carPrice);
		car.setRoadTax(roadTax);
		car.setAC(ac);
		car.setPowerSteeer(powerSteer);
		car.setAccKit(accKit);
	    
	    CarFacade carfacade=CarFacade.getObject();
	    Boolean flag=carfacade.addcar(car);
	    System.out.println(flag);
	    if(flag==false)
	    	response.sendRedirect("car.jsp");
	    else
	    	response.sendRedirect("listCar");
		}


}

function fnValidateForm() {
    var nm = document.forms["myForm"]["name"].value;
	var letters = /^[A-Za-z]+$/; 
    var eFormat = /\S+@\S+\.\S+/;
    var phoneno = /^\d{10}$/;
	var addrFormat = /^[a-zA-Z0-9\,\' '\-]+$/;
	var bool=true;
	var e = document.forms["myForm"]["e-mail"].value;
	var ph = document.forms["myForm"]["ph"].value;
	var addr = document.forms["myForm"]["addr"].value;
	var gender=document.getElementsByName("gender");
	var qualification = document.forms["myForm"]["qualification"].value;
	var certi=document.getElementsByName("certi");
    if (nm == null || nm == ""||nm.length<Number(3)) {
        alert("Name must be filled out having minimum 3 letters");
        return false;
    }
	else if(!nm.match(letters)){
	 alert("Name can not contain  digits");
        return false;	
	}
	else if (e == null ||!e.match(eFormat)){
        alert("enter valid mail-id please");
        return false;
    }
	else if (ph == null || !ph.match(phoneno) ){
        alert("enter valid phone number please must contain 10 digits in it");
        return false;
    }
	else if (addr == null ||!addr.match(addrFormat) ){
        alert("please enter address . special characters are not allowed");
        return false;
    }
	
	else if (gender[0].checked==false &&gender[1].checked==false){
        alert("please select gender");
        return false;
    }
	else if(qualification=="")
	{
		 alert("please select qualification");
        return false;
	}
	else {
    for(var i=0;i<certi.length;i++){
        if(certi[i].checked==true)
        {
            bool=false;
            break;
        }
	}
        if(bool==true){
            alert("Please filled atleast one checkbox");
            return true;
        }
    
    }
	
}
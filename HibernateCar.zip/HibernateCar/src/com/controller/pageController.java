package com.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class pageController {

	
	@RequestMapping("/")
	public String show(){
		
		return "index";
	}
	
	@RequestMapping("listCar")
	public String  getCarList(){
		
		return "display";
	}
	
	
	@RequestMapping("carCreate")
	public String showCarCreatePage() {
		
		return "createCar";
	}
	
	
	
}

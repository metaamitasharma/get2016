package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.CarFacade;
import com.model.CarVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/pages/")
public class CarController {
	
	@Autowired
	CarFacade carfacade;
	
	
	@RequestMapping("addCar")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/model/bean.xml");
		
		String make=request.getParameter("make");
		String model=request.getParameter("model");
		String price1=request.getParameter("price");
		int price=Integer.parseInt(price1);
		
		String milage1=request.getParameter("milage");
		int milage=Integer.parseInt(milage1);
		String fuelCapacity1=request.getParameter("fuelCapacity");
		int fuelCapacity=Integer.parseInt(fuelCapacity1);
		
		
		
		String ac1=request.getParameter("ac");
		boolean ac;
		if(ac1.equals("true")){
			ac=true;
		}else{
			ac=false;
		}
		
	    CarVO car=context.getBean("CarVO", CarVO.class);
	    
	   
		car.setModel(model);
		car.setMilage(milage);
		
		car.setFuelCapacity(fuelCapacity);
		car.setPrice(price);
		car.setMake(make);
		car.setAc(ac);
	

	    Boolean flag=carfacade.addCar(car);
	
	    if(flag==false)
	    	response.sendRedirect("home.jsp");
	    else
	    	response.sendRedirect("createCar.jsp");
		}
	
	
	
	@RequestMapping("/carlist")
	public @ResponseBody List<CarVO> showCarList(){
		
		List<CarVO>listOfCar=carfacade.list();
		return listOfCar;
		
	}

}

package com.model;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class CarDAO {

	@Autowired
	SessionFactory factory;	//To create a session for the database operation

	
	
public boolean insertCar(CarVO car){
		

		
	    //creating session object  
	    Session session=factory.openSession();  
	      
	    //creating transaction object  
	    Transaction t=session.beginTransaction();  
	          
	   
	    session.persist(car);//persisting the object  
	      
	    t.commit();//transaction is committed  
	    session.close();  
	      
	    System.out.println("successfully saved");  
		return true;
		
		
	}


	public List<CarVO>listOfCars(){
		
	
	    //creating session object  
	    Session session=factory.openSession();  
	      
	    //creating transaction object  
	    Transaction t=session.beginTransaction();  
	 
	
	Query query=session.createQuery("from CarVO");
	System.out.println("Query is"+query);
		List<CarVO>carList=query.list();
		session.close();
		return carList;	
		
		
	}
	
	
	
	

}

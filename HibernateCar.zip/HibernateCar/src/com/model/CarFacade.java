package com.model;

import java.util.List;

import com.model.CarDAO;
import com.model.CarFacade;
import com.model.CarVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class CarFacade {

	
	@Autowired
	CarDAO carDaoObj;
	
	
	
	public boolean addCar(CarVO car) {
		
		
		return carDaoObj.insertCar(car);
	}
	
	public boolean update(CarVO car) {
	
		System.out.println("cardao object is"+carDaoObj);
		
	
		return true;
	}


	public List<CarVO> list() {
	
		System.out.println("cardao object is"+carDaoObj);
		return carDaoObj.listOfCars();
	}

	public boolean delete(CarVO car) {
		// TODO Auto-generated method stub
		//return carDaoObj.deleteCar(car);
		return true;
	}	
	
	/*public static CarFacade getObject(){
		if(carFacadeObject == null) {
			ApplicationContext context = new ClassPathXmlApplicationContext("/com/model/bean.xml");
			carFacadeObject = context.getBean("CarFacade", CarFacade.class);
			
		}
		return carFacadeObject;
	}
	*/
}

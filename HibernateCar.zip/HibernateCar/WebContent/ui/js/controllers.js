/* The controller for getting the car list */
listOfCars.controller('carList', function($scope, $http) {

    /* For getting the list of cars available */
    $scope.loadCars = function(){
        $http({method: 'GET', url: 'pages/carlist'}).then(function(response) {
            
                $scope.cars = response.data;
                console.log($scope.cars);
            
        });
    }
});
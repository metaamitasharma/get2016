/* Getting the list of car page application */
var listOfCars = angular.module('listOfCars', []);


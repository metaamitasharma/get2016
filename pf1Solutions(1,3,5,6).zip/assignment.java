package pf1assignment1;

public class assignment {
	int pow(int x,int y){
		int xPOWy=1;int temp;
		for(temp=0;temp<y;temp++)
		{ 
			xPOWy=xPOWy*x;
		}
		return xPOWy;
	}
	int tripletToDecimal(int triplet)
	{
		int num,count=0,dec=0;
		num=triplet;
		while(num>0)
		{
			dec=dec+((num%10)*pow(2,count++));
			num=num/10;
		}
		return dec;
	}
	
	int convertBinarytoOctal(int n)
	{
		int rem,place=0,octal=0;
		while(n>0)
		{
			rem=n%1000;
			octal=octal+(tripletToDecimal(rem))*pow(10,place++) ;
			n=n/1000;
			
		}
		
		return octal;
	}
}


package pf1Assignment5;

public class assignment5 {
	int ifAscending(int a[])
	{
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>a[i+1])
			{
				return 0;
			}
		}
		return 1;
	}
	int ifDescending(int b[])
	{
		for(int i=0;i<b.length;i++)
		{
			if(b[i]<b[i+1])
			{
				return 0; 
			}
		}
		return 1;
	}
	int isArraySorted(int input[])
	{
	 if(ifAscending(input)==1)
	 {
		 return 1;
	 }
	 else if(ifDescending(input)==1)
	 {
		 return 2;
	 }
	 else
	 {
		 return 0;
	 }
	}
	void msg(int output)
	{
	switch(output)
	{
	case 1:
		System.out.println("array is sorted in ascending order");
		break;
	case 2:
		System.out.println("array is sorted in descending order");
		break;
	case 0:
		System.out.println("array is unsorted");
		break;
	}
	}
	

}

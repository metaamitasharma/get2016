package Models;

public class CarVO extends VehicleVO {

	
	String make,model,engineCC,AC,powerSteeer,accKit,name;
	float fuelCap,mileage,price,roadTax;
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngineCC() {
		return engineCC;
	}
	public void setEngineCC(String engineCC) {
		this.engineCC = engineCC;
	}
	
	public String getAC() {
		return AC;
	}
	public void setAC(String aC) {
		AC = aC;
	}
	public String getPowerSteeer() {
		return powerSteeer;
	}
	public void setPowerSteeer(String powerSteeer) {
		this.powerSteeer = powerSteeer;
	}
	public String getAccKit() {
		return accKit;
	}
	public void setAccKit(String accKit) {
		this.accKit = accKit;
	}
	public float getFuelCap() {
		return fuelCap;
	}
	public void setFuelCap(float fuelCap) {
		this.fuelCap = fuelCap;
	}
	public float getMileage() {
		return mileage;
	}
	public void setMileage(float mileage) {
		this.mileage = mileage;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getRoadTax() {
		return roadTax;
	}
	public void setRoadTax(float roadTax) {
		this.roadTax = roadTax;
	}
	
	
}

package Models;

import java.awt.List;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import databases.CarDao;

/**
 * Servlet implementation class CarFacade
 */
@WebServlet("/CarFacade")
public class CarFacade extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarFacade() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	public Boolean addcar(String carname,String carCreater,String model,float mileage,String engineCC,float fuelCap,float carPrice,float roadTax,String ac,String powerSteer,String accKit)
	{
		Boolean status=false;
		CarVO car=new CarVO();
		CarDao cardao=new CarDao();
		car.setName(carname);
		car.setMake(carCreater);
		car.setModel(model);
		car.setMileage(mileage);
		car.setEngineCC(engineCC);
		car.setFuelCap(fuelCap);
		car.setPrice(carPrice);
		car.setRoadTax(roadTax);
		car.setAC(ac);
		car.setPowerSteeer(powerSteer);
		car.setAccKit(accKit);
		
	
		
			 status=cardao.insertCar(car);
		
			// TODO Auto-generated catch block
			
		return status;
	}
	public Boolean updatecar(String updateBased,String carname,String carCreater,String model,float mileage,String engineCC,float fuelCap,float carPrice,float roadTax,String ac,String powerSteer,String accKit)
	{
		Boolean status=false;
		CarVO car=new CarVO();
		CarDao cardao=new CarDao();
		car.setName(carname);
		
		car.setMake(carCreater);
		car.setModel(model);
		car.setMileage(mileage);
		car.setEngineCC(engineCC);
		car.setFuelCap(fuelCap);
		car.setPrice(carPrice);
		car.setRoadTax(roadTax);
		car.setAC(ac);
		car.setPowerSteeer(powerSteer);
		car.setAccKit(accKit);
		
	
		System.out.println("carname"+carname);
			 status=cardao.updateCar(updateBased,car);
		
			// TODO Auto-generated catch block
			
		return status;
	}
	public ArrayList<CarVO> searchCarByName(String car)
	{
		CarDao cardao=new CarDao();
		ArrayList<CarVO>carList=new ArrayList<CarVO>();
		 try
	        {
			 String query="select * from car where name=?";
			 ResultSet rs=cardao.searchCarBy(query,car,"String");
	        
	           while (rs.next()) {
				CarVO cars=new CarVO();
				
				cars.setName(rs.getString(2));
				cars.setModel(rs.getString(6));
				cars.setEngineCC(rs.getString(7));
			    cars.setFuelCap(rs.getFloat(8));
				cars.setMileage(rs.getFloat(9));
				cars.setPrice(rs.getFloat(10));
				cars.setRoadTax(rs.getFloat(11));
				cars.setAC(rs.getString(12));
				cars.setPowerSteeer(rs.getString(13));
				cars.setAccKit(rs.getString(14));
				carList.add(cars);
			}
	        }
	        catch(SQLException e)
	        {
	        	System.out.println("Error in query");
	        }
	  
		return carList;
	}

	public ArrayList<CarVO> searchCarByPrice(String price)
	{
		CarDao cardao=new CarDao();
		ArrayList<CarVO>carList=new ArrayList<CarVO>();
		 try
	        {
			 String query="select * from car where price>?";
			 ResultSet rs=cardao.searchCarBy(query,price,"float");
	        
	           while (rs.next()) {
				CarVO cars=new CarVO();
				
				cars.setName(rs.getString(2));
				cars.setModel(rs.getString(6));
				cars.setEngineCC(rs.getString(7));
			    cars.setFuelCap(rs.getFloat(8));
				cars.setMileage(rs.getFloat(9));
				cars.setPrice(rs.getFloat(10));
				cars.setRoadTax(rs.getFloat(11));
				cars.setAC(rs.getString(12));
				cars.setPowerSteeer(rs.getString(13));
				cars.setAccKit(rs.getString(14));
				carList.add(cars);
			}
	        }
	        catch(SQLException e)
	        {
	        	System.out.println("Error in query");
	        }
	  
		return carList;
	}
	public ArrayList<CarVO> searchCarByModel(String model)
	{
		CarDao cardao=new CarDao();
		ArrayList<CarVO>carList=new ArrayList<CarVO>();
		 try
	        {
			 String query="select * from car where model=?";
			 ResultSet rs=cardao.searchCarBy(query,model,"String");
	        
	           while (rs.next()) {
				CarVO cars=new CarVO();
				System.out.println("ddf");
				cars.setName(rs.getString(15));
				cars.setMake(rs.getString(2));
				cars.setModel(rs.getString(6));
				cars.setEngineCC(rs.getString(7));
			    cars.setFuelCap(rs.getFloat(8));
				cars.setMileage(rs.getFloat(9));
				cars.setPrice(rs.getFloat(10));
				cars.setRoadTax(rs.getFloat(11));
				cars.setAC(rs.getString(12));
				cars.setPowerSteeer(rs.getString(13));
				cars.setAccKit(rs.getString(14));
				carList.add(cars);
			}
	        }
	        catch(SQLException e)
	        {
	        	System.out.println("Error in query");
	        }
	  
		return carList;
	}
	public ArrayList<String> viewCars()
	{
		CarDao cardao=new CarDao();
		ArrayList<String>carList=new ArrayList<String>();
		 try
	        {
			 String query="select model from car";
			 ResultSet rs=cardao.viewCarList(query);
	        
	           while (rs.next()) {
			
				
				
				
				carList.add(rs.getString(1));
			}
	        }
	        catch(SQLException e)
	        {
	        	System.out.println("Error in query");
	        }
	  
		return carList;
	}

	

}

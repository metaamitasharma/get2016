package Controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.CarFacade;
import Models.CarVO;
import Models.VehicleVO;

/**
 * Servlet implementation class CarController
 */
@WebServlet("/CarController")
public class CarController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String carname=request.getParameter("carName");
		String carCreater=request.getParameter("carCreater");
		String model=request.getParameter("model");
		
		String mile=request.getParameter("milage");
		float mileage=Float.parseFloat(mile);
		String engineCC=request.getParameter("engine");
		String fuel=request.getParameter("fuel");
		float fuelCap=Float.parseFloat(fuel);
		String price=request.getParameter("price");
		float carPrice=Float.parseFloat(price);
		String tax=request.getParameter("tax");
		float roadTax=Float.parseFloat(tax);
		String ac=request.getParameter("ac");
		String powerSteer=request.getParameter("powerSteer");
		String accKit=request.getParameter("accKit");
		System.out.println(carname);
	
	    CarVO car=new CarVO();
	    CarFacade carfacade=new CarFacade();
	    Boolean flag=carfacade.addcar(carname,carCreater,model,mileage,engineCC,fuelCap,carPrice,roadTax,ac,powerSteer,accKit);
	    System.out.println(flag);
	    if(flag==false)
	    	response.sendRedirect("car.jsp");
	    else
	    	response.sendRedirect("listController");
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}

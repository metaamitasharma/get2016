package databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

 public class ConnectionSingleton {

	private static ConnectionSingleton jdbc;  
    
    //JDBCSingleton prevents the instantiation from any other class.  
      private ConnectionSingleton() {  }  
       
   
        public static ConnectionSingleton getInstance() {    
                                    if (jdbc==null)  
                                  {  
                                           jdbc=new  ConnectionSingleton();  
                                  }  
                        return jdbc;  
            }  
           
  // to get the connection from methods like insert, view etc.   
        protected Connection getConnection()throws ClassNotFoundException, SQLException  
         {  
               
             Connection con=null;  
             Class.forName("com.mysql.jdbc.Driver");  
             con= DriverManager.getConnection("jdbc:mysql://localhost:3306/carbecho", "root", "amita");  
             return con;  
               
         }  
}

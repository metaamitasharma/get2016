package pf1Assignment2;

public class assignment2 {
	int[] removeDuplicate(int input[])
	{
		int[] output=new int[input.length];
		 int temp,count,outcurrentlength=0;
		 //temp is used to trace input array elements
		for(temp=0;temp<input.length;temp++)
		{
		 for(count=0;count<outcurrentlength;count++)
		 {
			 if(input[temp]==output[count])
			 {
				continue; 
			 }
			 else
			 {
				 output[outcurrentlength++]=input[temp];
			 }
		 }
		}
		outcurrentlength--;
		int[] ans = new int[outcurrentlength];
		for(int i=0;i<outcurrentlength;i++)
		{
			ans[i]=output[i];
		}
		
		return ans;
	}
}
